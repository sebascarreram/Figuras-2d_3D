from menu_principal import MenuFiguras

if __name__ == "__main__":
    MenuFiguras().mostrarMenu()
