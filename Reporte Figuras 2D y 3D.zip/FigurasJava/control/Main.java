package control;

public class Main {
    public static void main(String[] args) {
        // Creamos una nueva instancia del menú
        Menu menu = new Menu();

        // Ejecutamos el menú, que mostrará las opciones al usuario
        menu.mostrarMenu();
    }
}
