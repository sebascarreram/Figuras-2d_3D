package figuras2d

type Figura2D interface {
	CalcularArea() float64
	CalcularPerimetro() float64
}
