package main

func main() {
    MostrarMenu()
}
