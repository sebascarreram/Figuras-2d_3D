package figuras3d

import "math"

type Cubo struct {
	Lado float64
}

func (c Cubo) CalcularVolumen() float64 {
	return math.Pow(c.Lado, 3)
}
