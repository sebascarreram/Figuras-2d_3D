package figuras3d

type Figura3D interface {
	calcularVolumen() float64
}
