package figuras3d

import "math"

type Esfera struct {
	Radio float64
}

func (e Esfera) CalcularVolumen() float64 {
	return (4.0 / 3.0) * math.Pi * math.Pow(e.Radio, 3)
}
